from .mlp import MLP
from .cnn import CNN